<template>
  <div>
    <!-- <van-search placeholder="请输入搜索关键词"></van-search> -->
    <van-notice-bar
      wrapable
      :scrollable="false"
      text="to better remember"
    />
     ------------------ <br/>
     ---开发初衷：背单词，不想看那么多广告又下载APP <br/><br/>
     ------------------<br/><br/>
     ---基本查词、记词已经实现<br/><br/>
     ------------------<br/><br/>
     ---先在个人中心导入单词数据<br/><br/>
     ------------------<br/><br/>
     ---按个人不同程度的记忆深度（陌生、熟悉、掌握）<br/><br/>
     ------------------<br/><br/>
     ---使用特定算法计算需要多久再次复习<br/><br/>
     ------------------<br/><br/>
     ---届时-每日记词-页面【复习词】中会按时推送<br/>

  </div>
</template>
<script setup lang="ts">
</script>